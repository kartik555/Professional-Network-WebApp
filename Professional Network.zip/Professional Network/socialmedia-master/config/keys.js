module.exports = {
  mongoURI:
    "mongodb+srv://",
  secretOrKey: "secret"
};
